package com.fengjr.NeographX

//class MySpecTest extends JUnit4(MySpec)
////class MySpecSuite extends ScalaTestSuite(MySpec)
//object MySpecRunner extends ConsoleRunner(MySpec)

//object MySpec extends Specification {
//  "This wonderful system" should {
//    "save the world" in {
//      val list = Nil
//      list must beEmpty
//    }
//  }
object MySpec {
  def main(args: Array[String]): Unit = {
    println("Hello, world!")
  }
}
