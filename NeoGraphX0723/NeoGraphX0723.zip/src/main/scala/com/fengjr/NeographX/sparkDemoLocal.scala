package com.fengjr.NeographX

import org.apache.spark.{SparkConf, SparkContext}

object sparkDemoLocal {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("guoge").setMaster("local")
    conf.set("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
    conf.set("spark.neo4j.bolt.user","neo4j")
    conf.set("spark.neo4j.bolt.password","neo4j")

    val sc = new SparkContext(conf)
    val lines =  sc.textFile("C:\\Users\\jingjin.guo\\Desktop/guo.txt")
    val pairs = lines.map(s=>(s,1))
    pairs.reduceByKey((x, y)=>x+y).foreach(println)

    sc.stop()

  }
}
