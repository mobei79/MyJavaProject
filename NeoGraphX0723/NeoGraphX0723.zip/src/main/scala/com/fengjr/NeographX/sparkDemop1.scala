package com.fengjr.NeographX

import java.util.Date

import org.apache.spark.{SparkConf, SparkContext}
import org.neo4j.spark.Neo4j

object sparkDemop1 {
  def main(args: Array[String]): Unit = {
    val startTime=new Date()

//    val wordFile = "file:///usr/local/spark/mycode/wordcount/word.txt"
    val conf = new SparkConf().setAppName("GraphXNeo4j").setMaster("yarn")
      .set("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
      .set("spark.neo4j.bolt.user","neo4j")
      .set("spark.neo4j.bolt.password","neo4j")

    val sc = new SparkContext(conf)
    val neo = Neo4j(sc)
    val rawGraphnode=neo.cypher("MATCH (n:real_income_no) RETURN n LIMIT 25").loadNodeRdds
    rawGraphnode.foreach(println)
  }
}


//class test722p2 {
//  val spark = SparkSession.builder().appName("play").master("local[*]")
//    .config("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
//    .config("spark.neo4j.bolt.user","neo4j")
//    .config("spark.neo4j.bolt.password","neo4j")
//    .getOrCreate()
//  val neo = Neo4j(spark.sparkContext)

  // 使用sparkconf配置
  //  val conf = new SparkConf().setAppName("neo4j").setMaster("local[*]")
  //    .set("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
  //    .set("spark.neo4j.bolt.user","neo4j")
  //    .set("spark.neo4j.bolt.password","neo4j")
  //  val sc = new SparkContext(conf)
  //  val neo = Neo4j(sc)

  //通过 Neo4jConfig 来做配置
  //  val sparkSession1 = SparkSession.builder().master("local[*]").appName("LoadDataToNeo4j")
  //    .getOrCreate();
  //  val sc = sparkSession1.sparkContext
  //  val config = Neo4jConfig("bolt://10.10.204.30:7687","neo4j",Option("neo4j"))
  //  Neo4j(sc).cypher("CREATE (c:Client {id:1230}) return c").loadRdd
  //  sparkSession1.close()
//}