package com.fengjr.NeographX
import java.io.{File, PrintWriter}
import java.util.Date

import org.apache.spark.graphx._
import org.apache.spark.{SparkConf, SparkContext}
import org.neo4j.spark._

object sparkDemop2 {
  def main(args: Array[String]): Unit = {
    val startTime=new Date()

    //    val wordFile = "file:///usr/local/spark/mycode/wordcount/word.txt"
    val conf = new SparkConf().setAppName("GraphXNeo4j").setMaster("local")
      .set("spark.neo4j.bolt.url","bolt://10.10.203.132:7687")
      .set("spark.neo4j.bolt.user","neo4j")
      .set("spark.neo4j.bolt.password","kgfengjr")

    val sc = new SparkContext(conf)
    println( "Hello World!" )
    println(sc)
    val neo = Neo4j(sc)

    val rawGraphnode=neo.cypher("MATCH (p1:real_income_no) -[:HasPhone]-> (ph1:phone) -[f:HasCall]- (ph2:phone) <-[:HasPhone]- (p2:real_income_no) " +
      "where p1.channel_code=\"bj\" " +
      "RETURN id(p1) as source, id(p2) as target, f.call_cnt as weight ").loadNodeRdds
    val oc = rawGraphnode.count()
    println(oc)

    println("get data from Neo4j finish")
    val edgeRdd = rawGraphnode.map(x =>(x(0).toString,x(1).toString,x(2)))
      .map(x=>{Edge(x._1.toLong,x._2.toLong,x._3)})

    val g = Graph.fromEdges(edgeRdd,defaultValue = 1)
    val graph = lib.LabelPropagation.run(g,10)
      .vertices
      .collect
//      .sortWith(_._1<_._1)
    val writer = new PrintWriter(new File("guosiw.txt"))

//    writer.println(graph)
    for (i <- 0 until graph.length)
      writer.println(graph(i))
    writer.close()

  }
}


//class test722p2 {
//  val spark = SparkSession.builder().appName("play").master("local[*]")
//    .config("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
//    .config("spark.neo4j.bolt.user","neo4j")
//    .config("spark.neo4j.bolt.password","neo4j")
//    .getOrCreate()
//  val neo = Neo4j(spark.sparkContext)

// 使用sparkconf配置
//  val conf = new SparkConf().setAppName("neo4j").setMaster("local[*]")
//    .set("spark.neo4j.bolt.url","bolt://10.10.204.30:7687")
//    .set("spark.neo4j.bolt.user","neo4j")
//    .set("spark.neo4j.bolt.password","neo4j")
//  val sc = new SparkContext(conf)
//  val neo = Neo4j(sc)

//通过 Neo4jConfig 来做配置
//  val sparkSession1 = SparkSession.builder().master("local[*]").appName("LoadDataToNeo4j")
//    .getOrCreate();
//  val sc = sparkSession1.sparkContext
//  val config = Neo4jConfig("bolt://10.10.204.30:7687","neo4j",Option("neo4j"))
//  Neo4j(sc).cypher("CREATE (c:Client {id:1230}) return c").loadRdd
//  sparkSession1.close()
//}