package com.fengjr.NeographX

/**
 * Hello world!
 *
 */
object App {
  def main(args: Array[String]): Unit = {
    println("Hello, world!")
  }
  println( "Hello World!" )
}
