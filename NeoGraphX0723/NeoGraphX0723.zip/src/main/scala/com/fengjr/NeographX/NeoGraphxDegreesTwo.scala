package com.fengjr.NeographX

object NeoGraphxDegreesTwo {

}
